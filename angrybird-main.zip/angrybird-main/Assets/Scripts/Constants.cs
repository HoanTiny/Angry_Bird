using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public static class Constants
{
    public const string BIRDINDEX = "birdIndex";
    public const string VOLUME = "volumePref";
    public const string ENEMY = "enemy";
}
